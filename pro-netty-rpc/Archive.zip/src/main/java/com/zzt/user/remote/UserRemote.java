package com.zzt.user.remote;

import java.util.List;

import com.zzt.netty.util.Response;
import com.zzt.user.bean.User;

public interface UserRemote {
	public Response saveUser(User user);
	public Response saveUsers(List<User> users);


}
