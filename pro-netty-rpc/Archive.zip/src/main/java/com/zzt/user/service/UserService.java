package com.zzt.user.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.zzt.user.bean.User;

@Service
public class UserService {
	public void save(User user) {
		
	}

	public void saveList(List<User> users) {
		// TODO Auto-generated method stub
		
	}

}
